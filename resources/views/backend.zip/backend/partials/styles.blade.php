 <!-- BEGIN: Vendor CSS-->
    
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/vendors.min.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/charts/apexcharts.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/extensions/toastr.min.css')}}">
 <!-- END: Vendor CSS-->

 <!-- BEGIN: Theme CSS-->
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/bootstrap.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/bootstrap-extended.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/colors.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/components.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/themes/dark-layout.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/themes/bordered-layout.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/themes/semi-dark-layout.css')}}">

 <!-- BEGIN: Page CSS-->
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/core/menu/menu-types/vertical-menu.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/pages/dashboard-ecommerce.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/plugins/charts/chart-apex.css')}}">
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/plugins/extensions/ext-component-toastr.css')}}">
 
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/forms/select2.min.css')}}">
 <!-- END: Page CSS-->

 <!-- BEGIN: Custom CSS-->
 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/assets/css/style.css')}}"> 
 <!-- END: Custom CSS-->

 <link rel="stylesheet" type="text/css" href="{{asset('public/backend/assets/css/style.css')}}"> 
                   {{-- http://localhost/premad/satta-matka/public/backend/vendors/css/tables/datatable/dataTables.bootstrap5.min.css --}}
 <!--<link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/tables/datatable/dataTables.bootstrap5.min.css')}}">-->
 <!--<link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/tables/datatable/responsive.bootstrap5.min.css')}}">-->
 <!--<link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/tables/datatable/buttons.bootstrap5.min.css')}}">-->
 <!--<link rel="stylesheet" type="text/css" href="{{asset('public/backend/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css')}}">-->
 
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
  <style>
        .card-datatable{
            padding: 9px;
        }
        tr{
            border-bottom: 1px solid rgb(105 94 94 / 20%) !important;
            height: 60px;
        }
        table.dataTable tbody tr.even {
            background-color: #f3f2f7;

        }
        .dt-button {
            border-color: #4b4b4b !important;
            background-color: #4b4b4b !important;
            color: #fff !important;
        }
        .app-content{
            background-color: #fff;
        }
        .table-responsive{
            padding:1%;
        }
    </style>
 
 
 